link weight: https://drive.google.com/drive/folders/1sardIqNvxqBQM9GN_MsK_JyYs2TYQRqn?usp=sharing
link data: https://drive.google.com/drive/folders/14DeLjawFcaTeQDjslPtqIy0jOXxFeK4V?usp=sharing
Chỉnh lại các đường dẫn để chạy 